
/*import { Fragment } from 'react';
import './App.css';
import Restaurant from './Restaurant';

function App() {
  return (
    <div className="App">
      <header className="App-header"/>
    {Restaurant.map((Restaurant, index) => (
      <RestaurantCard
        key={index}
        name={Restaurant.name}
        location={Restaurant.location}
        Rating={Restaurant.Rating}
        img={Restaurant.image}
      />
    ))}
  </div>

      { <Introduction/> 
      <Restaurant/>
      
      }

  );
}
       

export default App;
// import componentName from "filename"
import './App.css';
import Student from './Student';
import Friends from './Friends';
function App() {
  var name="arun"
  return (
    <>
    <Student sname="riya" course="php" />
    <Student sname="ankush" course="react"/>
    <Student sname="anurag" course="node"/>
    <Student sname={name}/>
    <hr/>
    <Friends/>
    </>
  );
}

export default App;
import './App.css';
import Employee from './Employee';

function App() {
  return (
    <>
    <br></br>
    <Employee sname="Aishwarya" department="IT" designation="Full-Stack Developer" join_Date="1-07-2024" />
    <br></br>
    <Employee sname="Aishwarya" department="IT" designation="Full-Stack Developer" join_Date="1-07-2024"/><br></br>
    <Employee sname="Aishwarya" department="IT" designation="Full-Stack Developer" join_Date="1-07-2024"/><br></br>
    <Employee sname="Aishwarya" department="IT" designation="Full-Stack Developer" join_Date="1-07-2024"/><br></br>
  
    </>
  );
}
import './App.css';

import Restaurant from './Restaurant';
// import componentName from "filename"
function App() {
  return (
    <>
    { <Restaurant/> }
    </>
  );
}

export default App;
import Tourist from './Tourist';
// import componentName from "filename"
function App() {
  return (
    <>
    { <Tourist/> }
    </>
  );
}

export default App;*/
import EmployeeD from './EmployeeD';
// import componentName from "filename"
function App() {
  return (
    <>
      { <EmployeeD/> }
    </>
  );
}

export default App;
